function [pac_value, pac_sig] = pac_wb(data, srate, lo_freq_phase, hi_freq_phase, lo_freq_amp, hi_freq_amp, surrogate_runs)

%
% function [pac_value, pac_sig] = pac(data, srate, lo_freq_phase, hi_freq_phase, lo_freq_amp, hi_freq_amp, surrogate_runs)
% Usage: pac(data, 1000, 4, 8, 80, 150, 1000)
%
% This script calculates the phase amplitude coupling (PAC) between two pass bands.
%
% This function requires 7 inputs:
% data: a single channel of continuous time-series data
% srate: sampling rate of the input data
% lo_freq_phase: lower frequency bound for the phase bandpass
% hi_freq_phase: upper frequency bound for the phase bandpass
% lo_freq_amp: lower frequency bound for the amplitude bandpass
% hi_freq_amp: upper frequency bound for the amplitude bandpass
% surrogate_runs: the number of surrogate runs used to calculate statistical significance of the PAC value.
%
% The function returns the PAC value (between 0 and 1) as well as the significance of that value compared to
% surrogate temporal shifting between the phase and amplitude series.
%
% Bradley Voytek
% Copyright (c) 2011
% University of California, San Francisco
% Department of Neurology

% filter
phasedata = eegfilt(data, srate, lo_freq_phase, []);
phasedata = eegfilt(phasedata, srate, [], hi_freq_phase);
phasedata = angle(hilbert(phasedata)); % phase

ampdata = eegfilt(data, srate, lo_freq_amp, []);
ampdata = eegfilt(ampdata, srate, [], hi_freq_amp);
ampdata = abs(hilbert(ampdata)); % amplitude
ampdata = eegfilt(ampdata, srate, lo_freq_phase, []);
ampdata = eegfilt(ampdata, srate, [], hi_freq_phase);
ampdata = angle(hilbert(ampdata)); % phase modulation of amplitude

pac_value = abs(sum(exp(1i * (phasedata - ampdata)), 'double')) / length(data); % pac calculation

if surrogate_runs > 0
    spac = zeros([1 surrogate_runs]); % initialize
    permarray = randperm(length(data));
    permarray = permarray(1:surrogate_runs);
    % surrogate analyses for significance testing
    for si = 1:length(permarray)
        spac(si) = abs(sum(exp(1i * (circshift(phasedata, [-1 permarray(si)]) - ampdata)), 'double')) / length(data); % shift phase series
    end

    % Significance using Weibull distribution
    weibull_coeffs = wblfit(spac);
    pac_sig_wbl = 1-wblcdf(pac_value, weibull_coeffs(1), weibull_coeffs(2));


    % Significance using normal distribution
    pac_sig = normcdf(-abs((pac_value - mean(spac)) / std(spac)), 0, 1) .* 2; % Is the multiplication by 2 necessary for this test?

    % % Comparing the two distributions with a histogram of the surrogate pac
    % figure;
    % [nhist,xhist] = hist(spac,20);
    % bar(xhist,nhist,'k'); hold on;
    % binwidth = (max(xhist)-min(xhist))/numel(nhist);
    % plot_xvals = linspace(xhist(1),xhist(end),1000);
    % plot(plot_xvals,wblpdf(plot_xvals,weibull_coeffs(1),weibull_coeffs(2))*numel(spac)*binwidth, 'r', 'LineWidth', 3);
    % plot(plot_xvals,normpdf(plot_xvals,mean(spac),std(spac))*numel(spac)*binwidth, 'b', 'LineWidth', 3);
    % plot([pac_value pac_value], [0 max(nhist)], 'g', 'LineWidth', 4);
    % legend('Hist','Weibull','Normal','Real PAC');
    % title({['PAC Value: ' num2str(pac_value,'%0.4f')], ...
    %   ['Normal Significance: ' num2str(pac_sig,'%0.3f')], ...
    %   ['Weibull Significance: ' num2str(pac_sig_wbl,'%0.3f')], ...
    %   ['Note: Norm Sig is multiplied by 2']});

end

clear data srate lo_freq_phase hi_freq_phase lo_freq_amp hi_freq_amp surrogate_runs phasedata ampdata spac permarray si




