function pacdat = pac_pp(raw_data, good_channels, sampling_rate, low_frequency, high_frequency, car)

%
% function pacdat = pac_pp(raw_data, good_channels, sampling_rate, low_frequency, high_frequency, car)
% Usage: pacdat = pac_pp(raw_data, [1:25 29 31 44:64], 1000, [4 8], [80 150], 0)
%
% This script calculates the phase/amplitude coupling (PAC) between the
% phase of the low_frequency and the amplitude of the high_frequency for
% any set of good_channels in the matrix of raw_data
%
% This function requires 5 inputs and accepts 6
% data: A matrix of data where rows are chnnels and columns are time-points
% good_channels: vector of indices of the "good" channels to be included in
% the analysis
% sampling_rate: sampling rate of the input data
% low_frequency: the upper and lower limits of the phase passband
% high_frequency: the upper and lower limits of the amplitude passband
% car: switch to put data in Common Average Reference or not
%
% 
% Bradley Voytek
% Copyright (c) 2011
% University of California, San Francisco
% Department of Neurology


% Put data in common average reference
if nargin > 5
    if (car == 1)
        ref = mean(raw_data, 1);
        for x = 1:size(raw_data, 1)
            raw_data(x, :) = raw_data(x, :) - ref;
        end
        clear x ref
    end
end

raw_data = raw_data(good_channels, :);

% Initialize PAC variable
pacdat = zeros([1 size(raw_data, 1)]);

% Calculate PAC
for chanIt = 1:size(raw_data, 1)
    signal = raw_data(chanIt, :);
        
    % Extract low frequency analytic phase
    low_frequency_phase = eeg_butter(signal, low_frequency(1), low_frequency(2), sampling_rate, 3);
    low_frequency_phase = eegfilt(signal, sampling_rate, low_frequency(1), []);
    low_frequency_phase = eegfilt(low_frequency_phase, sampling_rate, [], low_frequency(2));
    low_frequency_phase = angle(hilbert(low_frequency_phase));
        
    % Extract low frequency analytic phase of high frequency analytic amplitude
    high_frequency_phase = eegfilt(signal, sampling_rate, high_frequency(1), []);
    high_frequency_phase = eegfilt(high_frequency_phase, sampling_rate, [], high_frequency(2));
    high_frequency_phase = abs(hilbert(high_frequency_phase));
    high_frequency_phase = eegfilt(high_frequency_phase, sampling_rate, low_frequency(1), []);
    high_frequency_phase = eegfilt(high_frequency_phase, sampling_rate, [], low_frequency(2));
    high_frequency_phase = angle(hilbert(high_frequency_phase));
 
    % Calculate PAC
    pacdat(chanIt) =...
        abs(sum(exp(1i * (low_frequency_phase - high_frequency_phase)), 'double'))...
        / length(high_frequency_phase);
end
clear chanIt good_channels low_frequency high_frequency sampling_rate signal low_frequency_phase high_frequency_phase raw_data
